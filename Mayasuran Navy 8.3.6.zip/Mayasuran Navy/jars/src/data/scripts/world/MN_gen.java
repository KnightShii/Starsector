package data.scripts.world;

import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;

public class MN_gen implements SectorGeneratorPlugin {

    @Override
    public void generate(SectorAPI sector) {

    }
}
