package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;

import data.scripts.weapons.ai.MSS_grenadestickyAI;
import data.scripts.weapons.ai.MSS_plasmabombAI;
import data.scripts.world.ChaseMairaathSwitcher;
import data.scripts.world.MN_gen;
//import exerelin.campaign.SectorManager;
import exerelin.campaign.PlayerFactionStore;
import exerelin.campaign.SectorManager;
import exerelin.campaign.intel.BuyColonyIntel;
import org.dark.shaders.light.LightData;
import org.dark.shaders.util.ShaderLib;
import org.dark.shaders.util.TextureData;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.*;


public class MN_modPlugin extends BaseModPlugin {

    //public static final String antiMissile_ID = "SCY_antiS";
    //public static final String smartgun_ID = "MSS_smartgun_shot";
    //public static final String coasting_ID = "SCY_coastingS";
    //public static final String laser_ID = "SCY_laserS";
    //public static final String bomberTorpedo_ID = "SCY_bomberTorpedo";
    //public static final String cluster_ID = "SCY_clusterS";    
    //public static final String rocket_ID = "SCY_rocketS";      
    //public static final String arc_ID = "SCY_arcS";

    ////////////////////////////////////////
    //                                    //
    //      MISSILES AI OVERRIDES         //
    //                                    //
    ////////////////////////////////////////

    @Override
    public PluginPick<MissileAIPlugin> pickMissileAI(MissileAPI missile, ShipAPI launchingShip) {
        switch (missile.getProjectileSpecId()) {
            case "MSS_thumper_grenade_sticky":
                return new PluginPick<MissileAIPlugin>(new MSS_grenadestickyAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            case "MSS_bomb_plasma":
                return new PluginPick<MissileAIPlugin>(new MSS_plasmabombAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            default:
        }
        return null;
    }



    public static boolean isExerelin = false;

    private static void initMN() {
        if (isExerelin && !SectorManager.getCorvusMode()) {
            return;
        }
        new MN_gen().generate(Global.getSector());
    }

    private static void setExerelin(boolean bool)
    {
        isExerelin = bool;
    }
    ////////////////////////////////////////
    //                                    //
    //       ON APPLICATION LOAD          //
    //                                    //
    ////////////////////////////////////////

    @Override
    public void onApplicationLoad() throws ClassNotFoundException {
        setExerelin(Global.getSettings().getModManager().isModEnabled("nexerelin"));
        try {
            Global.getSettings().getScriptClassLoader().loadClass("org.lazywizard.lazylib.ModUtils");
        } catch (ClassNotFoundException ex) {
            String message = System.lineSeparator()
                    + System.lineSeparator() + "LazyLib is required to run at least one of the mods you have installed."
                    + System.lineSeparator() + System.lineSeparator()
                    + "You can download LazyLib at http://fractalsoftworks.com/forum/index.php?topic=5444"
                    + System.lineSeparator();
            throw new ClassNotFoundException(message);
        }


        //Check ShaderLib for lights
        try {
            Global.getSettings().getScriptClassLoader().loadClass("org.dark.shaders.util.ShaderLib");
            ShaderLib.init();
            //LightData.readLightDataCSV("data/lights/MSS_light_data.csv");
            //TextureData.readTextureDataCSV("data/lights/MSS_texture_data.csv");
        } catch (ClassNotFoundException ex) { }
    }

    ////////////////////////////////////////
    //                                    //
    //        ON NEW GAME CREATION        //
    //                                    //
    ////////////////////////////////////////

    @Override
    public void onNewGame() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (!haveNexerelin || SectorManager.getCorvusMode()){
            new MN_gen().generate(Global.getSector());
            Global.getSector().addScript(new ChaseMairaathSwitcher());
        }
    }


    @Override
    public void onNewGameAfterTimePass() {
        // handle Nex's governorship intel event
        // so governorship is regained properly if market is lost and retaken
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (haveNexerelin && SectorManager.getCorvusMode() && ChaseMairaathSwitcher.MAYASURA.equals(PlayerFactionStore.getPlayerFactionIdNGC()))
        {
            SectorEntityToken mairaath = Global.getSector().getEntityById(ChaseMairaathSwitcher.MAIRAATH);
            if (mairaath == null) return;
            MarketAPI market = mairaath.getMarket();
            if (market != null) {
                BuyColonyIntel intel = new BuyColonyIntel(market.getFactionId(), market);
                intel.init();
            }
        }
    }

    public static String msspyotr = "msspyotr"; //totally not from highfleet

    private static void addDefendersofMairaath() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Mayasura");
        SectorEntityToken a1 = system.getEntityById("mairaath");

        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();

        // Admiral
        PersonAPI msspyotrPerson = Global.getFactory().createPerson();
        msspyotrPerson.setId(msspyotr);
        msspyotrPerson.setFaction("Mayasura");
        msspyotrPerson.setGender(FullName.Gender.MALE);
        msspyotrPerson.setPostId(Ranks.POST_FLEET_COMMANDER);
        msspyotrPerson.setRankId(Ranks.POST_FLEET_COMMANDER);
        msspyotrPerson.setPersonality(Personalities.AGGRESSIVE);
        msspyotrPerson.setImportance(PersonImportance.VERY_HIGH);
        msspyotrPerson.setVoice(Voices.SOLDIER);
        msspyotrPerson.getName().setFirst("Pyotr");
        msspyotrPerson.getName().setLast("Shahin");
        msspyotrPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "msspyotr"));
        msspyotrPerson.getStats().setLevel(9);
        // fleet commander stuff
        msspyotrPerson.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
        msspyotrPerson.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
        msspyotrPerson.getStats().setSkillLevel(Skills.OFFICER_TRAINING, 1);
        msspyotrPerson.getStats().setSkillLevel(Skills.SUPPORT_DOCTRINE, 1);
        msspyotrPerson.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
        msspyotrPerson.getStats().setSkillLevel(Skills.OFFICER_MANAGEMENT, 1);
        // officer stuff
        msspyotrPerson.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 3);
        msspyotrPerson.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        msspyotrPerson.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        msspyotrPerson.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        msspyotrPerson.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        msspyotrPerson.getStats().setSkillLevel(Skills.HELMSMANSHIP, 3);
        msspyotrPerson.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 3);
        msspyotrPerson.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 3);
        msspyotrPerson.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 3);
        ip.addPerson(msspyotrPerson);

        // I have to make every single one of these bozos manually
        PersonAPI person1 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        person1.setId("mss_generic_officer1");
        person1.setPostId(Ranks.POST_OFFICER);
        person1.setRankId(Ranks.POST_OFFICER);
        person1.setPersonality(Personalities.AGGRESSIVE);
        person1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person1.getStats().setLevel(7);

        PersonAPI person2 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        person2.setId("mss_generic_officer2");
        person2.setPostId(Ranks.POST_OFFICER);
        person2.setRankId(Ranks.POST_OFFICER);
        person2.setPersonality(Personalities.AGGRESSIVE);
        person2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person2.getStats().setLevel(7);

        PersonAPI person3 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        person3.setId("mss_generic_officer3");
        person3.setPostId(Ranks.POST_OFFICER);
        person3.setRankId(Ranks.POST_OFFICER);
        person3.setPersonality(Personalities.AGGRESSIVE);
        person3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person3.getStats().setLevel(7);

        PersonAPI person4 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        person4.setId("mss_generic_officer4");
        person4.setPostId(Ranks.POST_OFFICER);
        person4.setRankId(Ranks.POST_OFFICER);
        person4.setPersonality(Personalities.AGGRESSIVE);
        person4.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person4.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person4.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person4.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person4.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person4.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person4.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person4.getStats().setLevel(7);

        PersonAPI person5 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        person5.setId("mss_generic_officer5");
        person5.setPostId(Ranks.POST_OFFICER);
        person5.setRankId(Ranks.POST_OFFICER);
        person5.setPersonality(Personalities.AGGRESSIVE);
        person5.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person5.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person5.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person5.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person5.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person5.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person5.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person5.getStats().setLevel(7);

        PersonAPI person6 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        person6.setId("mss_generic_officer1");
        person6.setPostId(Ranks.POST_OFFICER);
        person6.setRankId(Ranks.POST_OFFICER);
        person6.setPersonality(Personalities.AGGRESSIVE);
        person6.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person6.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        person6.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        person6.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        person6.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 3);
        person6.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person6.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person6.getStats().setLevel(7);

        PersonAPI reckless1 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        reckless1.setId("mss_reckless1");
        reckless1.setPostId(Ranks.POST_OFFICER);
        reckless1.setRankId(Ranks.POST_OFFICER);
        reckless1.setPersonality(Personalities.RECKLESS);
        reckless1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 3);
        reckless1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        reckless1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        reckless1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        reckless1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless1.getStats().setLevel(7);

        PersonAPI reckless2 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        reckless2.setId("mss_reckless2");
        reckless2.setPostId(Ranks.POST_OFFICER);
        reckless2.setRankId(Ranks.POST_OFFICER);
        reckless2.setPersonality(Personalities.RECKLESS);
        reckless2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 3);
        reckless2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        reckless2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        reckless2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        reckless2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless2.getStats().setLevel(7);

        PersonAPI reckless3 = Global.getSector().getFaction("mayasura").createRandomPerson(FullName.Gender.ANY);
        reckless3.setId("mss_reckless3");
        reckless3.setPostId(Ranks.POST_OFFICER);
        reckless3.setRankId(Ranks.POST_OFFICER);
        reckless3.setPersonality(Personalities.RECKLESS);
        reckless3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 3);
        reckless3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
        reckless3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
        reckless3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 3);
        reckless3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless3.getStats().setLevel(7);


        FleetParamsV3 params = new FleetParamsV3(
                a1.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "mayasura",
                2f, // quality override route.getQualityOverride()
                FleetTypes.PATROL_LARGE,
                1f, // combatPts(minimal so special ships can be added)(1000f otherwise)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );
        params.officerNumberMult = 2f;
        params.officerLevelBonus = 4;
        params.officerNumberBonus = 4;
        params.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        params.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
        params.averageSMods = 2;
        params.commander = Global.getSector().getImportantPeople().getPerson(msspyotr);
        params.flagshipVariantId = "MSS_Victory_Elite";
        CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);
        if (fleet == null || fleet.isEmpty()) return;
        fleet.setFaction("mayasura", true);
        fleet.getFlagship().setShipName("MSS Mairaath Arisen");
        //fleet.setCommander(Global.getSector().getImportantPeople().getPerson("de_admiral"));
        //fleet.getFlagship().setOwner(1);
        fleet.getFlagship().setId("MSS_Victory_Elite");
        fleet.getFleetData().addFleetMember("MSS_Skyrend_Elite").setCaptain(person1);
        fleet.getFleetData().addFleetMember("MSS_National_Elite");
        fleet.getFleetData().addFleetMember("MSS_Javanicus_B_Elite").setCaptain(person2);
        fleet.getFleetData().addFleetMember("MSS_Mokarran_Elite");
        fleet.getFleetData().addFleetMember("MSS_Arjuna_Elite");
        fleet.getFleetData().addFleetMember("MSS_Conquest_Elite").setCaptain(person3);
        fleet.getFleetData().addFleetMember("MSS_Nebulosa_Elite");
        fleet.getFleetData().addFleetMember("MSS_Champion_Elite").setCaptain(person4);
        fleet.getFleetData().addFleetMember("MSS_Champion_Elite");
        fleet.getFleetData().addFleetMember("MSS_Champion_Elite");
        fleet.getFleetData().addFleetMember("MSS_Champion_Elite");
        fleet.getFleetData().addFleetMember("MSS_Gyrfalcon_Elite").setCaptain(person5);
        fleet.getFleetData().addFleetMember("MSS_Gyrfalcon_Elite");
        fleet.getFleetData().addFleetMember("MSS_Winghead_Elite").setCaptain(person6);
        fleet.getFleetData().addFleetMember("MSS_Winghead_Elite");
        fleet.getFleetData().addFleetMember("MSS_Heron_Elite");
        fleet.getFleetData().addFleetMember("MSS_Heron_Elite");
        fleet.getFleetData().addFleetMember("MSS_Patriot_Elite").setCaptain(reckless1);
        fleet.getFleetData().addFleetMember("MSS_Patriot_Elite");
        fleet.getFleetData().addFleetMember("MSS_Gyrfalcon_Elite");
        fleet.getFleetData().addFleetMember("MSS_Falcon_Elite").setCaptain(reckless2);
        fleet.getFleetData().addFleetMember("MSS_Hammerhead_Elite").setCaptain(reckless3);
        fleet.getFleetData().addFleetMember("MSS_Hammerhead_Elite");
        fleet.getFleetData().addFleetMember("MSS_Sunder_Elite");
        fleet.getFleetData().addFleetMember("MSS_Sunder_Elite");
        fleet.getFleetData().addFleetMember("MSS_Argentavis_Elite");
        fleet.getFleetData().addFleetMember("MSS_Argentavis_Elite");
        fleet.getFleetData().addFleetMember("MSS_Loyalist_Elite");
        fleet.getFleetData().addFleetMember("MSS_vigilance_m_elite");
        fleet.getFleetData().addFleetMember("MSS_vigilance_m_elite");
        fleet.getFleetData().addFleetMember("MSS_vigilance_m_elite");
        fleet.getFleetData().addFleetMember("MSS_Tiburo_Elite");
        fleet.getFleetData().addFleetMember("MSS_Tiburo_Elite");
        fleet.getFleetData().addFleetMember("MSS_Tiburo_Elite");
        fleet.getFleetData().addFleetMember("MSS_Nailer_Elite");
        fleet.getFleetData().addFleetMember("MSS_Nailer_Elite");
        fleet.getFleetData().addFleetMember("MSS_Nailer_Elite");
        fleet.getFleetData().addFleetMember("MSS_Mako_Elite");
        fleet.getFleetData().addFleetMember("MSS_Mako_Elite");
        fleet.getFleetData().addFleetMember("MSS_Mako_Elite");
        fleet.getFleetData().addFleetMember("MSS_Mako_Elite");
        fleet.setNoFactionInName(true);
        fleet.setName("The Vengeance of Mairaath");
        // a1.getMarket().getContainingLocation().addEntity(fleet);
        a1.getContainingLocation().addEntity(fleet);
        fleet.setAI(Global.getFactory().createFleetAI(fleet));
        fleet.setMarket(a1.getMarket());
        fleet.setLocation(a1.getLocation().x, a1.getLocation().y);
        fleet.setFacing((float) Math.random() * 360f);
        fleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, a1, (float) Math.random() * 90000f, null);
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        MarketAPI mairaath = Global.getSector().getEconomy().getMarket("mairaath");
        if (mairaath != null) {
            addDefendersofMairaath();
        }
    }
	
}