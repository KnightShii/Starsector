

Standard information and "legalities"
============================================
This Read me is to inform you that **the mod is provided as is**. The mod will be updated as I see fit and I can help with small bugs. If an older edition of the mod is requested I can only guarantee what I have put together from 0.7 upwards. Older editions have been lost or deleted. Otherwise it is standard stuff that is touted on the forums. Give credit were due, do not use my work without permission and you may edit it for *!*personal use only*!*

--Azmond


============================================


Credits
============================================
:***:Main team:***:
Azmond-- Head Development, coder, writer, and graphics designer (basically everything)
Viymese-- co-developer, writer, ideas, head test-monkey and initial coder
Knight Chase- Developer, remaster guy, gamer

:!*!: Special thanks to :!*!:
Alex-- For making a game I truly and utterly have loved moding for.
David-- For being insightful, polite, and helpful more than you may have known.
Mesotronik-- Code/graphical/writing assistance, Sound for the Actel Cannon, and being helpful in ways you may not know.

FallenShogun-- For taking an interest and being a rather awesome fellow and unfortunate testing bed.
Nemonemo-- For being an unfortunate testing bed and encouragement through public exposure of the mod (I'm genuinely sorry if I've made you mad).



:**:Others of note and credit to be given:**:
Avanitia-- For general helpfulness and helping me get Metelson's out of it's slump.
Bastion.Systems-- For inspiration given on the new flag and Critique.
Blaze-- For general quality assurance and play-testing, as well as critique.
Dark Revenant-- initial help setting up for when I first begun modding
Deathfly-- Code assistance, first ship-systems, first help given to mod production, and general helpfulness
Helmut-- Graphics assistance, sprite creation/critique and advice
Tartiflette-- Graphics assistance and advice

*THANK YOU TEST MONKEYS*
AxelMC131--  Test-monkey 1
CumsTM--	Test-monkey 5
KnightChase-- Test-monkey 2
Wunder-- Test-monkey 3
Yui-Chan-- Test-monkey 4



Finally, thank you to those who play this Mod and those who have commented on the thread.  Without your help, comments, and knowing/Unknowing encouragement; I would have made little in the way of progress and may've stopped my idea altogether.

Thank you for Downloading Metelson Industries. Enjoy the rocks with what riches you may find in your flying spuds.




===================================================
++++ Change Log starting from 4/16/2017 onward ++++
===================================================

To do in the coming month in no particular order:
	: Develop 3 analogs to vanilla ships that are unique in some reasonable fashion.
		Sernavis- Gemini counter
	: Develop 2 more fighters to fill Missing Niches in Metelson.
	: Develop and realease a fully re-done Mantarn(mantarndone) and Metelson Hammerhead
	
	added 11/05/2020
		Redraw Varingur, keep old Varingur as a Pirate Variation.
		add Pala Skins 
		Consider more Phase Ships?... yeah... More Phase Ships with the Rostor, perhaps 2 more? R.O.M.A, Ragona, and lastly Zepest
	

04/28/2021
	New graphics and skins for:
		Farin, Farin Pirate, Farin Luddic and Pather
		Pala, Pala Luddic, Pala Pirate
		Mantarn
		Varingur

11/03/2020

	Oh hello American Hellscape that is Politics...

	Normalized all fuel for Metelson ships. The fuel on all ships has been changed to a value that is similar to a ship in the vanilla game. Detailing all of them would be tedious and frankly not worth it. Long story short, a lot of 100's were replaced.
	
	Redrew the Varingur slightly, a small change to the artwork, basically a clean up
	
	

10/07/2020
	
		Mantarn given a face-lift *HIDDEN TURRTES REMOVED*
			Variants updated for new turrets. 3 small ballisic, 2 small composite	1 medium compsite, 1 medium Balistic, and 1 large Ballistic.
			Stats adjusted to make it more competitive as a result of hidden turrets being removed.
			Added Built-in Ionic Hull-Nodes
			Ship System changed to Ammo Feeder
			Hull&Armor unchanged
			Max Flux upped from 8000 to 10000
			Flux Dissipation from 390 to 450
			Ord. Points unchanged
			Speed from 60 to 70
			Acceleration from 30 to 45
			Deceleration unchanged
			Max turn changed from 20 to 40 acceleration unchanged
			Shield Effenciy from 0.8 to 0.7  upkeep and arc unchanged.
			All other stats unchanged
		Varingian speed changed from 75 to 65 to reflect it's size better...
		
		Ionic Hull-Nodes also impact EMP. Ionic Hull nodes now reduce EMP by 35%
		OP points upped to 6 from 8.

08/11/2020

	Farin given a face-lift and 2 variations. Luddic and Pather. 
		Both are Skins and largely the same as Farin is with some minor changes and have been implemented into Luddic AND Ludic Path Fleets.
	Hound (MI) skin given a face-lift

07/19/2020
	Supplies/rec & mo or supply Recovery/Maintenance Checked and normalized.
	Drengur 30 to 48
	

07/17/2020
	Updated Obex Description to properly describe the vessel.
		Obex Armor nerfed to 175 from 250
		OBex hull lowered to 350 from 450
		Obex Acceleration/decceleration lowered from 70/50 to 30/30
	This will make the Obex more of a slow-burner and lag behind most ships but unable to really stop well... It also reflects the terrible Engine placement.


	Added Farin Luddic Variations
		Luddic Pather (murderPotato)
		Luddic Church (Farin (LC))

07/01/2020
All Wing BP's Removed from ship Data.CVS, Fighter BPs would be showing up for production. I wasn't aware of this. Thank you personage, you know who you are. :)
Fight hull BP's should now NO LONGER appear.

The following Planets have been adjusted within Rock:
Ragnus - Size and Population are now the same, that being 7
  	| Industry of  Refining Removed as that has been taken by Anvil.
Viymese - Size increased to 6 from 4 to allow for 1 new industry. 
	| Industry of Fuel Producition added to Viymese, this will give players another place to go to if they only have Metelson's for fuel production.

Started work on Farin variation Implimation.

05/20/2020

Prices nomralized for ships!/Fighters!! (skins and some ships unaffected).
WTF was I thinking... I have no idea. Fighters made some sense at least, the rest? I, I just don't know, anyway!:
	Negl !!  Price from:5500 now to 6500
		+added a single Crackler to their arrment as well to make them more relvant as an attack/escort fighter. No changes were made to the vessel otherwise.
	Grudiver !! Price from: 3750 now to 4000
	Obex !! Price from: 11250 now to 10000
		+ added 1 more to the wing making it a wing of 3 from 2. No changes were made to the vessel otherwise.
	Golgata !! Price from: 7750 now to 8000 
	Pala ! Price unaffected
	Mudder ! Price from: unaffected 
	Vigil ! Price from:  10500 now to 11000
	Stinulv ! Price from: 12000 now to 12500
	Mite ! Price from: 4042 now to 4250
	Cavos ! Price from: 12100 now to 14000
	Farin ! Price from: 10250 now to 10000
	Glima ! Price from: 12000 now to 12500
	R.O.M.A ! Price from: 22750 now to 18000
	Actel H35 ! Price from: 26533 now to 27000
	Actel H35A ! Price from: 22533 now to 23000
	Rastrum ! Price from: 20000  now to 36000
	Custos ! Price from: 19250 now to 38000
	Varingur ! Price from: 26000 now to 36000
	Securi ! Price from: 22000 now to 32000
	Mantarn !  Price 32000 no to 40000
	Gadfar ! Price from: 65000 now to 70000
	Drengur ! Price from: 200000 now to 330000
	Thrudgelmir ! Price from: 160000 now to 425000
	Acutor ! Price from: 65000 now to 150000

These prices are anologus with ship/fighter in the game that match or closely match what the ship/fighter does. SOme prices are descreased (rarely) or Increased (more likely) depending on the ship. For example the Actel H35 is more expansive than the H35A because of the specialized turret canopy.

Feedback on prices will affect furture ships.

05/04/2020

	Added System tag to Thrudgelmir's main laser... whoops.


Changes as of 04/27/2020:
	Adjusted Crackler PD damge, flux, spread, and burst to make it a bit more... Punchy. (I'm a lazy sod and half the time this isn't read I think.)
	Adjusted the following ship's Prices and DP and stats:
		Gadfar: Price increased to 65000, DP increased to 15
		Varingur: Price increased to 26000, DP increased to 12, FP increased to 10
		Drengur: Shield Efficiency upped to an even 1.
		Acutor: Sheild Upkeep lowered to 0.42, Price increased to 65000 (50k was a bit too low I felt... Uped it.)
		Thrudgelmir: Required crew lowered to 350
	Ajudsted Sprite for Glima- this has resulted in the game likely going to 
	

Changes as of 03/13/2020:
	
	Heavy Maser Damage/Shot: 170 from 284 Flux/Shot: 145 from 132 Burst Rate: 2.5 from 3 Gives it a bit more punch without eating flux.
	Ship roles adjusted to avoid market over-saturation (IE, I buggered up, had numbers too high. This has been changed to more realistice ideals.
	Pala: Shield Efficiency adjusted from 1 to 0.7
	Descriptions.csv adjusted to removed references to older ships that have been removed.

As of 03/12/2020::
	
	Final set up for the new release. Mainly typos and making sure code isn't broken. Please let me know if you have any glaring issues or problems.

As of 10/09/19::

	Major changes-
		. Several ships have been removed.
			Pala MKL, Grancursor, and Cringer as well as several developmental ships that may be released later or for memetic/genuine reasons.
		. Fleet Composition edited to be a mixture of a neutral fleet with Metelson vessels.
		. Many, many lines placed into rules. If any errors are seen in spelling that is not intentional (EG, "Y'all've ye' ya' Hey'a etc etc.) please message me in the forums or in the UNoffical Starsector Discord.
		. Market conditions readjusted slightly and Rock ring-system toned down somewhat (only ONE asteroid-ring is needed Azmond, holy crap).
		. Added a new outpost in Tyle called Voutyro that orbits around Kardara (may develop this into a seprate planet with a moon).
			
			. . . Probably a butt-ton of other stuff I've honestly forgotten.


02/09/18::
	
	Thrudgelmir- sheilds normalized to upkeep of 1 and Effenciy of .6
				 Hull increased to 16000 from 12000
				 Armor from 1250 to even 1300
				 Turrets and load-outs edited
	Drengur- Upkeep cahnged to 30 an 30 for delopment and upkeep/month
				 all other stats unchanged
	Acutor-
			Hull lowered to a more reasonable level from 18000 to 11000
	
	no further bug-fixxes. . . ATM.
	



12/18/2017::

	Adjusted all Deployment costs/Repairs normalized, OP normalized and ship Variants adjusted for new OP stats.
	New usable ships:
		Scab - Cargo pod basically, marginally better than the Mudder in terms of usability for cost.
	Added Ship Ustos- ***NOT IMPLIMENTED***, but can be obtained in Console commands with mi_ustos_standard all Meletson ships will have the prefix mi_SHIPNAME_standard for the basic type.
	
	All ships have received a once-over and balance change in some way. I lost count and haven't the faintest what all the changes are.
	
		
8/18/2017::
	Removed all instances of the Liten Field and replaced the Pala's system with a burn-drive. The reason being that hte liten at that time, had begun to cause a bug for some reason.
	
8/12/2017::

	All CR normalized on Metelson vessels.
			All ships- save for one -have been given normal CR stats
				A lot has been done to the ships either to give them more load-outs that're worth a damn, or otherwise.
			Some load-outs are suicide or otherwise rare to see.
			Ye' have been warned and keep on your toes.

	Rostor Field's have been lowered to only 5 ships in the metelson fleet. Replacements have been made to the others.
		Rostor Fields no longer have individual boosts to speed.
		Rostor Fields now have the same cool-down and regen as the Damper Field.
	Actel H35 now set in standard fleet generation as a "2", meaning it's more rare to actually see (hopefully) Likewise, fleet generation has been normalized copying the Nueteral fleet generation.
		Actel h35 speed has been lowered to 60 from 
		Actel hull has been lowered to 3000 from 
		Actel CR lowered to 300 from 400
	Actel Cannon nerfed and flux generation increased
		Standard cannon has a default spread of 8 from 10
		Actel Canopy has a a max spread of 12 from 15.
			Both cannons have had an increase to their cool-down phase and flux generation.
			Both cannons have a projectile speed of 800 from 1000 making the shot easier to dodge for smaller targets. 
			(unless it's point blank which, yeah, good luck...)			
	Obex- NERFED, no longer is it a flying Hammer barrage.
		removed one hammer torpedo and replaced the Mining laser and Molaris Blaster with a single Maser.
	Securi-
		CR reduced from 575 to 300
		Hull reduced from 4250 to 3000
		Armor reduced from 600 to 400
		Turn-rate lowered from 60 to 20
		Speed unchanged
		Flux reduced from 6000(!!!) to 4250
		Shield arc reduced from 220 to 200
	Pala:L
		Speed reduced from 170 to 165
		Acceleration reduced from 175 to 150
		Shield arc reduced from 270 to 220
	Thrudgelmir
		Fleet points increased to 20
			NEXE: mining strength reduced from 125 to 75
	NEXE:
		Additional mining weapons added-
				Molaris Blaster mining strength set to 5. Half of the standard mining blaster.
	
	Fighter refit time normalized
		All fighters have refit times parallel with vanilla counterparts.
		Grudiver is set to 5
		Negl is set to 10
		Obex and Golgata are set to 15
		
	Actel Egg removed 
	

6/19/2017::

	Hullmods not intended for use on ships hidden properly now.

6/18/2017::


Ships--
	Actel h35 given FP increase of 1 from 

Wings--
	
	Drones made to be very rare to find and use for the most part and given reduced range among other things.
	
Ship-systems--
	
	no changes

Descriptions--

	no changes
	
Weapons--

	Padent System mining values for nexe lowered to 3 from 6

6/17/2017::


Ships--
	mi_drengur Offcially Added
	Thrudgelmir Lives!!!
	mi_cringer added
	several other ships have a slight graphics update

Ship-systems--
	
	no changes

Descriptions--
	mining lance name changed to Maser Lance to fit with the Maser beam and So on
	Added new descriptions as needed.
	
Weapons--
	Gulimnjor added
	Padent system added
	Combat MG given a burst of 16 with 1.75 second chargedown (now rivals the Needler rather than being a plinky MG....)

4/16/2017::

Ships--
	mi_wolf (stiulv) given Manuvering Jets and small buff to stats to compensate for Mobility loss making the ship viable for combat again. 			Speed from 110 to 120
		armor from 180 to 220
		Flux from 1800 to 1950
		Dissipation from 140 to 150

Ship-systems--
	
	Rostor Fields nerfed slightly and given charges to avoid becoming overpowered.	

Descriptions--
	Varingurt is no longer on sale and has been removed from production. (Spelling error for Varingur fixxed)

Weapons--
	Kasta-MRSM given a buff:
	 	EMP set to 10
		Damage from 50 to 55
	Mining Lance OP added from 10 to 11
