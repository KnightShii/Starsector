package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.MutableStat;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class metelson_hullnode extends BaseHullMod
{
  public static final float DAMAGE_REDUCTION = 15.0F;
  public static final float DAMAGE_PENALTY = 30.0F;
  private static Map mag = new HashMap();

  static { mag.put(ShipAPI.HullSize.FRIGATE, Float.valueOf(50.0F));
    mag.put(ShipAPI.HullSize.DESTROYER, Float.valueOf(100.0F));
    mag.put(ShipAPI.HullSize.CRUISER, Float.valueOf(150.0F));
    mag.put(ShipAPI.HullSize.CAPITAL_SHIP, Float.valueOf(200.0F));
  }


  public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id)
  {
    stats.getArmorBonus().modifyFlat(id, ((Float)mag.get(hullSize)).floatValue());

    stats.getProjectileDamageTakenMult().modifyMult(id, 0.75F);
    stats.getEmpDamageTakenMult().modifyMult(id, 0.75F);
    stats.getFragmentationDamageTakenMult().modifyMult(id, 0.75F);
    stats.getBeamDamageTakenMult().modifyMult(id, 1.3F);
  }

  public String getDescriptionParam(int index, ShipAPI.HullSize hullSize)
  {
    if (index == 0) return "" + ((Float) mag.get(HullSize.FRIGATE)).intValue();
    if (index == 1) return "" + ((Float) mag.get(HullSize.DESTROYER)).intValue();
    if (index == 2) return "" + ((Float) mag.get(HullSize.CRUISER)).intValue();
    if (index == 3) return "" + ((Float) mag.get(HullSize.CAPITAL_SHIP)).intValue();
    if (index == 4) return "" + (int) DAMAGE_REDUCTION + "%";
    if (index == 5) return "" + (int) DAMAGE_PENALTY + "%";
    return null;
  }

  public metelson_hullnode() {}
}
