package data.hullmods;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;

public class mi_PrimitiveHangerBay extends com.fs.starfarer.api.combat.BaseHullMod
{
  public static final float REFIT_SPEED = 50.0F;
  
  public mi_PrimitiveHangerBay() {}
  
  public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id)
  {
    stats.getFighterRefitTimeMult().modifyMult(id, 2.0F);
  }
  
  public String getDescriptionParam(int index, ShipAPI.HullSize hullSize)
  {
    if (index == 0) {
      return "50%";
    }
    return null;
  }
  
  public boolean isApplicableToShip(com.fs.starfarer.api.combat.ShipAPI ship)
  {
    return ship.getHullSpec().getHullId().startsWith("mi_");
  }
}
