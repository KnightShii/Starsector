package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;

import java.util.HashMap;
import java.util.Map;

public class MSS_SkysplitterM_system extends BaseHullMod {

    private final Map<String, Integer> SWITCH_SYSTEM_TO = new HashMap<>();

    {
        SWITCH_SYSTEM_TO.put("MSS_Skyrend_Elite", 1);
        SWITCH_SYSTEM_TO.put("MSS_Skyrend_EliteB", 2);
        SWITCH_SYSTEM_TO.put("MSS_Skyrend_EliteC", 3);
        SWITCH_SYSTEM_TO.put("MSS_Skyrend_EliteD", 0);
    }

    private final Map<Integer, String> SWITCH_SYSTEM = new HashMap<>();

    {
        SWITCH_SYSTEM.put(0, "MSS_Skyrend_Elite");
        SWITCH_SYSTEM.put(1, "MSS_Skyrend_EliteB");
        SWITCH_SYSTEM.put(2, "MSS_Skyrend_EliteC");
        SWITCH_SYSTEM.put(3, "MSS_Skyrend_EliteD");
    }

	    // map containing the hullmod that corresponds to each weapon option
    private final Map<Integer,String> SYSTEMSWITCH = new HashMap<>();
    {
        SYSTEMSWITCH.put(0,"MSS_selector_SkyrendA");
        SYSTEMSWITCH.put(1,"MSS_selector_SkyrendB");
        SYSTEMSWITCH.put(2,"MSS_selector_SkyrendC");
        SYSTEMSWITCH.put(3,"MSS_selector_SkyrendD");
    }

    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {

        //trigger a system switch if none of the selector hullmods are present
        boolean switchSystem = true;
        for(int i=0; i<SWITCH_SYSTEM_TO.size(); i++){
            if(stats.getVariant().getHullMods().contains(SYSTEMSWITCH.get(i))){
                switchSystem=false;
            }
        }

        //swap the source variant and add the proper hullmod
        if (switchSystem && stats.getEntity() != null && ((ShipAPI) stats.getEntity()).getHullSpec() != null) {

            int switchTo = SWITCH_SYSTEM_TO.get(((ShipAPI) stats.getEntity()).getHullSpec().getHullId());

            ShipHullSpecAPI ship = Global.getSettings().getHullSpec(SWITCH_SYSTEM.get(switchTo));
            ((ShipAPI) stats.getEntity()).getVariant().setHullSpecAPI(ship);

            //add the proper hullspec
            stats.getVariant().setHullSpecAPI(ship);
            //add the proper hullmod
            stats.getVariant().addMod(SYSTEMSWITCH.get(switchTo));
        }
    }
        @Override
        public String getDescriptionParam(int index, HullSize hullSize) {
            if (index == 0) return "A";
            if (index == 1) return "B";
            if (index == 2) return "C";
            if (index == 3) return "D";
            return null;
        }
    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return ( ship.getHullSpec().getHullId().startsWith("MSS_"));
    }
}


